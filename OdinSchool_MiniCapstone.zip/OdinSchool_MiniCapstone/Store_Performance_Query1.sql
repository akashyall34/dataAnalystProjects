SELECT Store.Store_Id, sum(amount) AS Revenue
FROM payment
INNER JOIN rental
ON payment.rental_id = rental.rental_id
INNER JOIN staff
ON rental.staff_id = staff.staff_id
INNER JOIN store
ON staff.store_id = store.store_id
GROUP BY store.store_id
ORDER BY store.store_id DESC;


